function mode = nc_nofill_mode()
% NC_NOFILL_MODE:  returns integer mnemonic for NC_NOFILL
%
% USAGE:  mode = nc_nofill_mode;
mode = 256;
return


